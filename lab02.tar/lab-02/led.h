#ifndef _LED_H_
#define _LED_H_

void LED_init(void);

#endif // _LED_H_

